Melodee carries Debian bookworm's armhf runtime for 32-bit plug-ins (the loader, glibc,
libstdc++ and libgcc_s), unchanged. glibc is under the LGPL 2.1 or later; libstdc++ and
libgcc_s under the GPL 3 with the GCC Runtime Library Exception (see the copyright files).
It also carries Debian bookworm's aarch64 libsndfile (LGPL 2.1 or later) with libFLAC, libogg,
libvorbis, libvorbisenc, libopus (BSD-style) and libmp3lame (LGPL 2 or later), unchanged.
Their source is these Debian packages' source, on snapshot.debian.org:
  libc6-armhf-cross 2.36-8cross1
  libstdc++6-armhf-cross 12.2.0-14cross1
  libgcc-s1-armhf-cross 12.2.0-14cross1
  libogg0 1.3.5-3
  libflac12 1.4.2+ds-2
  libvorbis0a 1.3.7-1
  libvorbisenc2 1.3.7-1
  libopus0 1.3.1-3
  libmp3lame0 3.100-6
  libsndfile1 1.2.0-1+deb12u1
It is also available on request from the Melodee project for three years from each release.
