#!/bin/sh
# Melodee v0.7.2-lab for the MPC Sample: starts Melodee from autorun/melodee
# once the stock app is up. Delete this autorun folder to uninstall.
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
/bin/sh "$D/melodee/sd-boot.sh" "$D/melodee" > /run/melodee-sd.log 2>&1 || true
